orangtua(maleleng, darwati).
orangtua(bondeng, darwati).
orangtua(maleleng, suyuti).
orangtua(bondeng, suyuti).
orangtua(maleleng, tini).
orangtua(bondeng, tini).
orangtua(mahyuddin, mukhraeni).
orangtua(darwati, mukhraeni).
orangtua(mahyuddin, methyawan).
orangtua(darwati, methyawan).
orangtua(mahyuddin, majeedah).
orangtua(darwati, majeedah).
menikah(mahyuddin, darwati).
laki(maleleng).
laki(mahyuddin).
laki(suyuti).
perempuan(bondeng).
perempuan(darwati).
perempuan(tini).
perempuan(mukhraeni).
perempuan(methyawan).
perempuan(majeedah).

ibu(X, Y) :- orangtua(X, Y), perempuan(X).
ayah(X, Y) :- orangtua(X, Y), laki(X).
anak(X, Y) :- orangtua(Y, X).
anaklaki_laki(X, Y) :- orangtua(Y, X), laki(X).
anakperempuan(X, Y) :- orangtua(Y, X), perempuan(X).
suami(X, Y) :- menikah(X, Y), laki(X).
istri(Y, X) :- menikah(X, Y), perempuan(Y).
kakek(X, Z) :- orangtua(X, Y), orangtua(Y, Z), laki(X).
nenek(X, Z) :- orangtua(X, Y), orangtua(Y, Z), perempuan(X).
saudara(Y, Z) :- orangtua(X, Y), orangtua(X, Z), \+ (Y = Z).
saudaralaki_laki(Y, Z) :- saudara(Y, Z), laki(Y).
saudaraperempuan(Y, Z) :- saudara(Y, Z), perempuan(Y).
bibi(X, Y) :- saudara(X, Z), orangtua(Z, Y), perempuan(X).
paman(X, Y) :- saudara(X, Z), orangtua(Z, Y), laki(X).
cuculaki(X, Z) :- orangtua(Y, X), orangtua(Z, Y), laki(X).
cucuperempuan(X, Z) :- orangtua(Y, X), orangtua(Z, Y), perempuan(X).
